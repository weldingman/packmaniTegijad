class Wall{
  constructor(wall){
    this.wall = wall;
  }
}
